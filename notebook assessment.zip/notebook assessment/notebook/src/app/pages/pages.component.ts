import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.css']
})
export class PagesComponent implements OnInit {

  constructor() { }

  page1Flag = true;
  page2Flag = false;
  page3Flag = false;
  page4Flag = false;
  page5Flag = false;

  p1Data: any = "";
  p2Data: any = "";
  p3Data: any = "";
  p4Data: any = "";
  p5Data: any = "";

 


  ngOnInit(): void {

   this.p1Data =   localStorage.getItem('p1')    ?     localStorage.getItem('p1') : '';
   this.p1Data = this.p1Data.indexOf('null') == -1 ?  this.p1Data : '';
   this.p2Data =   localStorage.getItem('p2')    ?   localStorage.getItem('p2') : '';
   this.p2Data = this.p2Data.indexOf('null') == -1 ?  this.p2Data : '';
   this.p3Data =   localStorage.getItem('p3')   ?    localStorage.getItem('p3') : '';
   this.p3Data = this.p3Data.indexOf('null') == -1 ?  this.p3Data : '';
   this.p4Data =   localStorage.getItem('p4')   ?    localStorage.getItem('p4'): '';
   this.p4Data = this.p4Data.indexOf('null') == -1 ?  this.p4Data : '';
   this.p5Data =   localStorage.getItem('p5')   ?    localStorage.getItem('p5'): '';
   this.p5Data = this.p5Data.indexOf('null') == -1 ?  this.p5Data : '';
 
  }

  saveData() {
    debugger;

    localStorage.setItem("p1", this.p1Data ? this.p1Data : '');
    localStorage.setItem("p2", this.p2Data ? this.p2Data : '');
    localStorage.setItem("p3", this.p3Data ? this.p3Data : '');
    localStorage.setItem("p4", this.p4Data ? this.p4Data : '');
    localStorage.setItem("p5", this.p5Data ? this.p5Data : '');

  }

  loadPage(page: any) {
    this.saveData()

    if (page == 'l1') {

      this.page1Flag = true;
      this.page2Flag = false;
      this.page3Flag = false;
      this.page4Flag = false;
      this.page5Flag = false;

    } else if(page == 'l2') {

      

        this.page1Flag = false;
        this.page2Flag = true;
        this.page3Flag = false;
        this.page4Flag = false;
        this.page5Flag = false;
  
      
    }
    else if(page == 'l3') {

      

      this.page1Flag = false;
      this.page2Flag = false;
      this.page3Flag = true;
      this.page4Flag = false;
      this.page5Flag = false;

    
  }
  else if(page == 'l4') {

      

    this.page1Flag = false;
    this.page2Flag = false;
    this.page3Flag = false;
    this.page4Flag = true;
    this.page5Flag = false;

  
}
else if(page == 'l5') {

      

  this.page1Flag = false;
  this.page2Flag = false;
  this.page3Flag = false;
  this.page4Flag = false;
  this.page5Flag = true;


}


  }

}
